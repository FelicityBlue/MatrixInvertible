This program check if the 2x2 matrix is invertible or not.

If not, then print out The Matrix is not invertible.

If it is then, it prints out The Matrix is invertible,
and give you the resultant matrix.

Possible future update: Checking for all matrix size